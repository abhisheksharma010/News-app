# News App
Fetch news from API and list them inside a RecyclerView.

</br>
</br>
[![Watch this video](https://img.youtube.com/vi/ttIfesjYDQQ/0.jpg)] (https://www.youtube.com/watch?v=ttIfesjYDQQ)
